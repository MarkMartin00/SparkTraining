package com.Mark.test;

import com.Mark.Person;

public class TestPerson {

    public static void main(String[] args) {
        Person adam = new Person();
    }
}