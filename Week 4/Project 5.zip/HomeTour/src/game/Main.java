package game;
import java.util.Scanner;

import fixtures.Room;
import game.RoomManager;

public class Main {
	public static void main(String[] args) {
			name = name;
			shortDescription = shortDescription;
			longDescription = longDescription;
		}
		
		for (int i = 0; i < args.length; i++) {
		System.out.println("Argument #" + i + " " + args[i]);
			System.out.println(RoomManager.startingRoom);
		
		
		Scanner scan = new Scanner(System.in);
			String name;
			boolean visiting =true;
		
			while (visiting) {
				System.out.println("What would you like to do?" + "/n" + "1. Check a fixture." + "/n" + "2. Go back into the last room." +
						"/n" + "3. Go to the next room" + "/n" + "4. You check another fixture.");
				String choice =scan.nextLine().toLowerCase();
				switch (choice) {
				case "1":
					
					break;
				case "2":
					
					break;
				case "3":
					
					break;
				case "4":
					
					break;
				default: 
					System.out.println("You take a minute to absorb the room again and think about your next decision.");
				}
			}
	                        
}
		}
		
	}
}
