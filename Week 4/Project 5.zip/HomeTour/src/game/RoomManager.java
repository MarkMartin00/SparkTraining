package game;

import fixtures.Room;

public class RoomManager extends Room {
	public static Room startingRoom;
	public RoomManager(String name, String shortDescription, String longDescription) {
		(name, shortDescription, longDescription);
	}
	
}
