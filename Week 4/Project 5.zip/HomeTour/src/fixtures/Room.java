package fixtures;

import java.util.Arrays;

public class Room extends Fixture {
	Room[] exits;
	Room[] rooms;
	Room startingRoom;
	
	public Room(String name, String shortDescription, String longDescription) {
		super(name, shortDescription, longDescription);
		this.exits = new Room[6]; 
	}
	
	public Room[] getExits() {
		return exits;
	}
		
	//public Room getExit(String direction) {
				
	//}
	
	public Room[] getRooms() {
		return rooms;
	}

	public void setRooms(Room[] rooms) {
		this.rooms = rooms;
	}

	public Room getStartingRoom() {
		return startingRoom;
	}

	public void setStartingRoom(Room startingRoom) {
		this.startingRoom = startingRoom;
	}

	@Override
	public String toString() {
		return "Room [exits=" + Arrays.toString(exits) + ", rooms=" + Arrays.toString(rooms) + ", startingRoom="
				+ startingRoom + "]";
	}

	public Room(String name, String shortDescription, String longDescription, Room[] exits, Room[] rooms,
			Room startingRoom) {
		super(name, shortDescription, longDescription);
		this.exits = exits;
		this.rooms = rooms;
		this.startingRoom = startingRoom;
	}

	public void setExits(Room[] exits) {
		this.exits = exits;
	}

	public void init() {
	    Room foyer = new Room(
			"The Foyer",
			"a small foyer",
			"The small entryway of a neo-colonial house. A dining room is open to the south, where a large table can be seen." + "\n"
			+ "The hardwood floor leads west into doorway, next to a staircase that leads up to a second floor." + "\n"
			+ "To the north is a small room, where you can see a piano.");
			this.rooms[0] = foyer;
	        this.startingRoom = foyer;
	}
	public void init1() {
		Room livingRoom = new Room(
			"The Living Room",
			"A nice living room with soft light",
			"A side living room of a smaller house used for a larger sofa and a coffee table. There are several smaller " +  "\n"
			+ "tables with lamps and brass lampshades. The dense brown carpet looks older but well kept. The small of mothballs " + "\n"
			+ "is faint upon your nose. The shades on the windows keep most of the light out and the fireplace brings in a dim light.");
			this.rooms[1]=livingRoom;
	}
	public void init2() {
		Room diningRoom = new Room(
			"The Dining Room",
			"An eatery with a large set table.",
			"You notice a large set table with croche table linens and eligant plates at first. A dancing hanging chandilier  " +  "\n"
			+ "hangs lighting the room brilliantly and several china cabinets line the walls with fine china placed in them. " + "\n"
			+ "The chairs and table is made of stained dark oak and been well kept. There are several candle holders on the walls.");
			this.rooms[2]=diningRoom;	
				}
	public void init3() {
		Room kitchen = new Room(
			"The kitchen",
			"A display of cuttery and fruits.",
			"You notice a large set table with croche table linens and eligant plates at first. A dancing hanging chandilier  " +  "\n"
			+ "hangs lighting the room brilliantly and several china cabinets line the walls with fine china placed in them. " + "\n"
			+ "The chairs and table is made of stained dark oak and been well kept. There are several candle holders on the walls.");
			this.rooms[3]=kitchen;	
				}
	public void init4() {
		Room hallway = new Room(
			"The Hallway",
			"A dim litted hall with many painted faces littering the walls.",
			"The long hall carpet is darker colors extending in the hallway, which is spiratic colored and isn't any particular pattern. " +  "\n"
			+ "The paintings on the walls at first glance appear, like any home, to be dozens of portraits of family photos or paintings " + "\n"
			+ "of long lost relatives. There is only one light in the middle of the hall and a doorway. The wall paper looks old and dirty.");
			this.rooms[4]=hallway;	
				}
	public void init5() {
		Room bathroom = new Room(
			"The bathroom",
			"Older Porcelen bathroom with a clawfoot cast iron tub.",
			"Immediatly you notice an old clawfoot bathtub at the center-end of the room. It's elegance but antiqueness is only  " +  "\n"
			+ "matched by it's deteriorating rust around the outside and creeky hardwood floors. The flooring around the tub seems " + "\n"
			+ "dryrotted from water damaged and the wallpaper seems to be peeling in some areas. The porcelain sink has a silver mirror "  + "\n"
			+ "hanging above it and all reflections seems to be distorted from the age of the mirrors wear. The toilet has seen better days.");
			this.rooms[5]=bathroom;	
				}
	public void init6() {
		Room cellar = new Room(
			"The cellar",
			"A dark room with dirt floors and strong moldy odors.",
			"Very little light enters here. The light that does enter comes in waves from the cracks in the hard wood floor from above. " +  "\n"
			+ "The wood stairs are steep and thin and there are many shelves that lay empty on the sides. There are few bottles that lay " + "\n"
			+ "on the shelves that appear as vintage wine. Most of them empty and one half full bottle of something that the label is not longer legible.");
			this.rooms[6]=cellar;	
	}
}
