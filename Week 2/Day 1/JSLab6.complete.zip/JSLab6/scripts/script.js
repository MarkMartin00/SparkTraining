console.log("Hello!");

//The following lines of code meant to create a constant 
//variable. To hold the numer of inches in a foot. 

let numInches;
numInches = 12;
var numFeet = numInches/12
var newInches = numInches%12
console.log(numFeet + " feet " + newInches +" inches");


//The next lines of code are meant to prompt the user
//to enter their name and then print it out to the console.

let myName = prompt("What is your name?");
console.log("Your name is " + myName);

//Finally, fix the following code so that it alerts 
//users that my favorite food is sushi.

let myFood = "sushi";
alert("Your favorite food is "+ myFood);