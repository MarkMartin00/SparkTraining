//Add your work to this file. 

/* Example
This is a variable declaration. 
Also referred to as a variable definition.
It typically will have a keyword and then the name 
of the variable. In this case, the variable is named 
firstVariable. The keyword let indicates to JavaScript
that we are defining a new variable.*/
let firstVariable; 



/* Your turn 
Define a variable named data */


/* Example
 Here we initialize firstVariable
 In other words we assign it a value for the first
 time. */
 firstVariable = 100;

 /* Now we can use our variable. 
 Let's print it to the console.
 
 Notice that to use our variable we don't need to
 use the keyword let again. We just use the name of 
 the variable.*/
 console.log(firstVariable);


 /*Your turn
 Initialize data to 5000*/
 let myOtherVariable = 5000;
 console.log(myOtherVariable);

 /*Then print your variable to the console.*/
const constVariable = "Can't be changed";
console.log(constVariable);

firstVariable = "Spaghetti";
console.log(firstVariable);
data = "27";
console.log(data);
//--constVariable = "Reassignment";
var myVar;
myVar = true;
myVar = false;
console.log(myVar);

console.log(varVariable);
console.log(abc);

let abc;
var varVariable;
