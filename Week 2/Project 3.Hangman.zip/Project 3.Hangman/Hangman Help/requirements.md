1. four sections in HTML:
* gallows section that displays images
* strikes section that displays incorrect guesses
* word section that shows word to guess and is slowly revealed
* guess section that contains a form where the player can type in their guess each round
2. Logic:
* have variables to keep track of game state
* create the three functions specified in the instructions that update their respective HTML sections
* create processGuess function to check guess, use three update functions, and to check if anyone wins