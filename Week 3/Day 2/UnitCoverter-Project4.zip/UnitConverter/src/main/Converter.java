package main;

import java.util.Scanner;

public class Converter {
	private static int MenuSelection = 0;

	public static void main(String[] args) {
		class MenuSelection {
			public String name;
		}
		MenuSelection menu = new MenuSelection();
		menu.name= "Please select an option:"; 
				
		MenuSelection cups= new MenuSelection();
		cups.name= "1. Cups to Teaspoons";
		MenuSelection miles= new MenuSelection();
		miles.name= "2. Miles to Kilometers";
		MenuSelection gallons= new MenuSelection();
		gallons.name= "3. US Gallons to Imperial Gallons";
		MenuSelection end= new MenuSelection();
		end.name= "4. Quit";
		//while loop with scanner in
		while (MenuSelection != 4) {
			System.out.println(menu.name);
			System.out.println(cups.name);
			System.out.println(miles.name);
			System.out.println(gallons.name);
			System.out.println(end.name);
			
	        int opt;
	        @SuppressWarnings("resource")
			Scanner MenuSelection = new Scanner(System.in);
	        System.out.println("Choose here.");
	        opt = MenuSelection.nextInt();
			switch(opt) {
				case 1:
					Scanner cupsToTeaspoons = new Scanner(System.in);
					System.out.println("What amount of cups do you need converted into teaspoons?.");
					int c = cupsToTeaspoons.nextInt();
					System.out.println("This is " + c*47.9860695 + " teaspoons.");
			        break;
				case 2:
					Scanner milesToKilometers = new Scanner(System.in);
					System.out.println("How many miles do you need  turned into Kilometers?.");
					int m =milesToKilometers.nextInt();
					System.out.println("This is "+ m*1.609344 + " kilometers.");
			        break;
				case 3:
					Scanner gallonsToImperial = new Scanner(System.in);
					System.out.println("How many Gallons would you like converted into his Roal Highnesses Imperial Gallons?.");
			        int i =gallonsToImperial.nextInt();
					System.out.println("This is "+i*0.8326741881485+ " Imperial gallons.");
			        break;
				case 4:
					System.out.println("Thank you, Come again!");
					return;
			}}}}		
			   
		
