
public class Parrot{

	public static void main(String[] args) {
		Parrot parrot = new Parrot();
		
		//call talk method
		parrot.talk();
		
		//greet human argument
		String person = "Bruster";
		parrot.greetHuman(person);
		
		//create "String name" for Greet human
		String[] words = {"Howdy", "Polly", "wanna", "cracker"};
		parrot.repeat(words);
		
		//define variables for i in main
		int numOfCrackers = parrot.countCrackers(10,11);
		System.out.println(numOfCrackers);
	}
	
	public void repeat(String[] words) {
		for(int i = 0; i<words.length; i++){
		    System.out.println(words[i]);
		}
		}
	
	public void talk() {
		System.out.println("Squawk, Squawk!");
	}
	
	public void greetHuman(String greetHum) {
		System.out.println("Squawk Squawk Aawk " + greetHum);
	}
	//define i
	public int countCrackers(int crackersKept, int crackersStolen) {
		return (crackersKept + crackersStolen);
	}
}