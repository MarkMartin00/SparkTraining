
public class StringMethods {
	public static void main(String[] args) {
		String str= "pancakes";
		String str1= "monday";
		String s=new String("Pancakes");
		String m=new String("Monday");
		System.out.println(str.equals("pancakes"));
		System.out.println(str == s);
		System.out.println(str1.length());
		System.out.println(str1 == m);
		String str2="supercalifragilisticexpialidocious";
		System.out.println(str2.length());
		System.out.println(str2.indexOf('c'));
		System.out.println(str2.indexOf('b'));
	}
}
