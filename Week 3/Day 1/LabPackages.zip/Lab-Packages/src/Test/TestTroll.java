package Test;

import Model.Troll;
import Model.Trolls.AnotherTroll;

public class TestTroll {
	public static void main(String[] args) {
		Troll troll = new Troll();
		AnotherTroll anotherTroll = new AnotherTroll();
		System.out.println(troll);
		System.out.println(anotherTroll);
	}
}
