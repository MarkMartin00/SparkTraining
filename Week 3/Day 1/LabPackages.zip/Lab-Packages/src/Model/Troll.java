package Model;

public class Troll {
	//empty class
}
