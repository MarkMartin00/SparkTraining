package Model.Trolls;

public class AnotherTroll {

}
