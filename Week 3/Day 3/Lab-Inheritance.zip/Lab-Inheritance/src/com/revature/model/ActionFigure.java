package com.revature.model;

public class ActionFigure extends Toy {
String eyeColor; 
  String skill;

  public ActionFigure() {
    this.eyeColor = "yellow";
    this.name = "Oliver Queen";
    this.skill= "arrow shooting";
  }

  public ActionFigure(String name, String eyeColor, String skill){
    this.name = name;
    this.eyeColor = eyeColor;
    this.skill = skill;
  }

  public String getEyeColor(){
     return this.eyeColor;
  }
  public String getSkill() {
	  return this.skill;
  }

  public void setEyeColor(String eyeColor){
     this.eyeColor = eyeColor;
  }
  public void setSkill(String skill) {
	  this.skill= skill;
  }

  public void makeTalk(){
     System.out.println("Ka Pow! I�m using my skill, "+this.skill);
  }
}